import React from "react";
import { BrowserRouter as Router, Routes, Route, Link, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Mail, ShoppingCart, User } from "lucide-react";

// Add your components and routes here...
export default function App() {
  return (
    <Router>
      <div>Hello SiraHat</div>
    </Router>
  );
}